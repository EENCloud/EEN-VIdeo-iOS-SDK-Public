//
//  EEN_Video_iOS_SDK.h
//  EEN-Video-iOS-SDK
//
//  Created by Suhaib Al Saghir on 27/10/2022.
//

#import <Foundation/Foundation.h>
#import "RTSPSession.h"
//! Project version number for EEN_Video_iOS_SDK.
FOUNDATION_EXPORT double EEN_Video_iOS_SDKVersionNumber;

//! Project version string for EEN_Video_iOS_SDK.
FOUNDATION_EXPORT const unsigned char EEN_Video_iOS_SDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <EEN_Video_iOS_SDK/PublicHeader.h>
